# -*- coding: utf-8 -*-
from odoo import models, fields, api

from odoo.exceptions import UserError, ValidationError
#Import logger
import logging
#Get the logger
_logger = logging.getLogger(__name__)

#External import
import datetime

class vanbandi(models.Model):
    _name = 'vanbandi.vanbandi'
    _description = u"Văn bản đi"
    _date_name = "date_start"
    _order = "sequence, name, id"

    name = fields.Char(required=True)
    numberOfUpdates = fields.Integer('Number of updates', help='The number of times the scheduler has run and updated this field')
    lastModified = fields.Date('Last updated')
    du_an_id = fields.Many2one('vanbanden.project',
                                 string='Du an',
                                 required=False)
    don_vi_soan_thao_id = fields.Many2one('hr.department',
                               string='Don vi soan thao',
                               required=False)
    can_bo_ki_nhay_id = fields.Many2one('res.users',
                              string='Can bo ki nhay',
                              default=lambda self: self.env.uid,
                              index=True, track_visibility='always',)
    ngay_van_ban = fields.Date(string='Ngay van ban', index=True, copy=False)
    code = fields.Char(string='Ki hieu', required=True, index=True, default='KH/')
    noi_gui_id = fields.Many2one('res.partner', string='Noi gui')
    trich_yeu = fields.Html(string='Trich yeu to trinh')
    nguoi_ki_id = fields.Many2one('res.users',
                                        string='Nguoi ki',
                                        default=lambda self: self.env.uid,
                                        index=True, track_visibility='always', )
    so_luong = fields.Integer('So luong')
    sequence = fields.Integer(string='Sequence', index=True, default=100000,
                              help="Gives the sequence order when displaying a list of tasks.")
    _sql_constraints = [
        ('code_uniq', 'unique (code)', u'Mã văn bản đã có!'),
    ]