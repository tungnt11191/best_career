# -*- coding: utf-8 -*-
{
    'name': 'Van ban di',
    'version': '1.0',
    'category': 'Tests',
    'description': """A module to verify the inheritance using _inherits.""",
    'author': 'Ban CNTT',
    'website': 'http://www.tanhoangminh.com.vn',
    'depends': ['base'],
    'data': [
        'security/vanbandi_security.xml',
        'security/ir.model.access.csv',
        'views/vanbandi_view.xml',
    ],
    'installable': True,
    'auto_install': False,
}
