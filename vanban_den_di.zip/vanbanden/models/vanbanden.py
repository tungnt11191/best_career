# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import json
from lxml import etree

from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools.safe_eval import safe_eval
from odoo import http
import urlparse
import random

import logging
import pprint
_logger = logging.getLogger(__name__)

class VanbandenTaskType(models.Model):
    _name = 'vanbanden.task.type'
    _description = 'Task Stage'
    _order = 'sequence, id'

    def _get_mail_template_id_domain(self):
        return [('model', '=', 'vanbanden.task')]

    def _get_default_vanbanden_ids(self):
        default_vanbanden_id = self.env.context.get('default_vanbanden_id')
        return [default_vanbanden_id] if default_vanbanden_id else None

    name = fields.Char(string='Stage Name', required=True, translate=True)
    description = fields.Text(translate=True)
    sequence = fields.Integer(default=1)
    vanbanden_ids = fields.Many2many('vanbanden.vanbanden', 'vanbanden_task_type_rel', 'type_id', 'vanbanden_id', string='Vanbandens',
        default=_get_default_vanbanden_ids)
    legend_priority = fields.Char(
        string='Priority Management Explanation', translate=True,
        help='Explanation text to help users using the star and priority mechanism on stages or issues that are in this stage.')
    legend_blocked = fields.Char(
        string='Kanban Blocked Explanation', translate=True,
        help='Override the default value displayed for the blocked state for kanban selection, when the task or issue is in that stage.')
    legend_done = fields.Char(
        string='Kanban Valid Explanation', translate=True,
        help='Override the default value displayed for the done state for kanban selection, when the task or issue is in that stage.')
    legend_normal = fields.Char(
        string='Kanban Ongoing Explanation', translate=True,
        help='Override the default value displayed for the normal state for kanban selection, when the task or issue is in that stage.')
    mail_template_id = fields.Many2one(
        'mail.template',
        string='Email Template',
        domain=lambda self: self._get_mail_template_id_domain(),
        help="If set an email will be sent to the customer when the task or issue reaches this step.")
    fold = fields.Boolean(string='Folded in Kanban',
        help='This stage is folded in the kanban view when there are no records in that stage to display.')


class Vanbanden(models.Model):
    _name = "vanbanden.vanbanden"
    _description = u"Văn bản đến"
    _inherit = ['mail.alias.mixin', 'mail.thread', 'ir.needaction_mixin']
    _inherits = {'account.analytic.account': "analytic_account_id"}
    _order = "sequence, name, id"
    _period_number = 5
    def get_alias_model_name(self, vals):
        return vals.get('alias_model', 'vanbanden.task')

    def get_alias_values(self):
        values = super(Vanbanden, self).get_alias_values()
        values['alias_defaults'] = {'vanbanden_id': self.id}
        return values

    @api.multi
    def unlink(self):
        analytic_accounts_to_delete = self.env['account.analytic.account']
        for vanbanden in self:
            if vanbanden.tasks:
                raise UserError(_(u'Không thể xóa văn bản có chứa giấy tờ liên quan như văn bản... Bạn phải xóa các giấy tờ liên quan trước hoặc đơn giản là ẩn nó đi.'))
            if vanbanden.analytic_account_id and not vanbanden.analytic_account_id.line_ids:
                analytic_accounts_to_delete |= vanbanden.analytic_account_id
        res = super(Vanbanden, self).unlink()
        analytic_accounts_to_delete.unlink()
        return res

    # @api.model
    # def search_read(self, domain=None, fields=None, offset=0, limit=None, order=None):
    #     a = 1

    def _compute_attached_docs_count(self):
        Attachment = self.env['ir.attachment']
        for vanbanden in self:
            vanbanden.doc_count = Attachment.search_count([
                '|',
                '&',
                ('res_model', '=', 'vanbanden.vanbanden'), ('res_id', '=', vanbanden.id),
                '&',
                ('res_model', '=', 'vanbanden.task'), ('res_id', 'in', vanbanden.task_ids.ids)
            ])

    def _compute_task_count(self):
        for vanbanden in self:
            vanbanden.task_count = len(vanbanden.task_ids)

    def _compute_task_needaction_count(self):
        vanbandens_data = self.env['vanbanden.task'].read_group([
            ('vanbanden_id', 'in', self.ids),
            ('message_needaction', '=', True)
        ], ['vanbanden_id'], ['vanbanden_id'])
        mapped_data = {vanbanden_data['vanbanden_id'][0]: int(vanbanden_data['vanbanden_id_count'])
                       for vanbanden_data in vanbandens_data}
        for vanbanden in self:
            vanbanden.task_needaction_count = mapped_data.get(vanbanden.id, 0)

    @api.model
    def _get_alias_models(self):
        """ Overriden in vanbanden_issue to offer more options """
        return [('vanbanden.task', u"Văn bản đến")]

    @api.multi
    def attachment_tree_view(self):
        self.ensure_one()
        domain = [
            '|',
            '&', ('res_model', '=', 'vanbanden.vanbanden'), ('res_id', 'in', self.ids),
            '&', ('res_model', '=', 'vanbanden.task'), ('res_id', 'in', self.task_ids.ids)]
        return {
            'name': _('Attachments'),
            'domain': domain,
            'res_model': 'ir.attachment',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'kanban,tree,form',
            'view_type': 'form',
            'help': _(u'''<p class="oe_view_nocontent_create">
                        Giấy tờ tài liệu được đính kèm thêm vào văn bản đến.</p><p>
                        Gửi thông báo hoặc ghi chú nội bộ cùng giấy tờ đính kèm để liên kết với văn bản.
                    </p>'''),
            'limit': 80,
            'context': "{'default_res_model': '%s','default_res_id': %d}" % (self._name, self.id)
        }

    @api.model
    def activate_sample_vanbanden(self):
        """ Unarchives the sample vanbanden 'vanbanden.vanbanden_vanbanden_data' and
            reloads the vanbanden dashboard """
        # Unarchive sample vanbanden
        vanbanden = self.env.ref('vanbanden.vanbanden_vanbanden_data', False)
        if vanbanden:
            vanbanden.write({'active': True})

        cover_image = self.env.ref('vanbanden.msg_task_data_14_attach', False)
        cover_task = self.env.ref('vanbanden.vanbanden_task_data_14', False)
        if cover_image and cover_task:
            cover_task.write({'displayed_image_id': cover_image.id})

        # Change the help message on the action (no more activate vanbanden)
        action = self.env.ref('vanbanden.open_view_vanbanden_all', False)
        action_data = None
        if action:
            action.sudo().write({
                "help": _(u'''<p class="oe_view_nocontent_create">Click để tạo văn bản mới.</p>''')
            })
            action_data = action.read()[0]
        # Reload the dashboard
        return action_data

    def _compute_is_favorite(self):
        for vanbanden in self:
            vanbanden.is_favorite = self.env.user in vanbanden.favorite_user_ids

    def _get_default_favorite_user_ids(self):
        return [(6, 0, [self.env.uid])]

    @api.model
    def default_get(self, flds):
        result = super(Vanbanden, self).default_get(flds)
        result['vanbanden_use_tasks'] = True
        return result

    # 0: Văn bản
    _type = fields.Integer(default=0, invisible=True)

    # Lambda indirection method to avoid passing a copy of the overridable method when declaring the field
    _alias_models = lambda self: self._get_alias_models()
    active = fields.Boolean(default=True,
        help="If the active field is set to False, it will allow you to hide the vanbanden without removing it.")
    sequence = fields.Integer(default=10, help="Gives the sequence order when displaying a list of Vanbandens.")
    analytic_account_id = fields.Many2one(
        'account.analytic.account', string='Contract/Analytic',
        help="Link this vanbanden to an analytic account if you need financial management on vanbandens. "
             "It enables you to connect vanbandens with budgets, planning, cost and revenue analysis, timesheets on vanbandens, etc.",
        ondelete="cascade", required=True, auto_join=True)
    favorite_user_ids = fields.Many2many(
        'res.users', 'vanbanden_favorite_user_rel', 'vanbanden_id', 'user_id',
        default=_get_default_favorite_user_ids,
        string='Members')
    is_favorite = fields.Boolean(compute='_compute_is_favorite', string='Show Vanbanden on dashboard',
        help="Whether this vanbanden should be displayed on the dashboard or not")
    label_tasks = fields.Char(string='Use Tasks as', default=u'Văn bản đến', help="Gives label to tasks on vanbanden's kanban view.")
    tasks = fields.One2many('vanbanden.task', 'vanbanden_id', string="Task Activities")
    resource_calendar_id = fields.Many2one('resource.calendar', string='Working Time',
        help="Timetable working hours to adjust the gantt diagram report")
    type_ids = fields.Many2many('vanbanden.task.type', 'vanbanden_task_type_rel', 'vanbanden_id', 'type_id', string='Tasks Stages')
    task_count = fields.Integer(compute='_compute_task_count', string="Tasks")
    task_needaction_count = fields.Integer(compute='_compute_task_needaction_count', string="Tasks")
    task_ids = fields.One2many('vanbanden.task', 'vanbanden_id', string='Tasks',
                               domain=['|', ('stage_id.fold', '=', False), ('stage_id', '=', False)])
    color = fields.Integer(string='Color Index')
    user_id = fields.Many2one('res.users', string='Vanbanden Manager', default=lambda self: self.env.user)
    alias_id = fields.Many2one('mail.alias', string='Alias', ondelete="restrict", required=True,
        help="Internal email associated with this vanbanden. Incoming emails are automatically synchronized "
             "with Tasks (or optionally Issues if the Issue Tracker module is installed).")
    alias_model = fields.Selection(_alias_models, string="Alias Model", index=True, required=True, default='vanbanden.task',
        help="The kind of document created when an email is received on this vanbanden's email alias")
    privacy_visibility = fields.Selection([
            ('followers', _('On invitation only')),
            ('employees', _('Visible by all employees')),
            ('portal', _('Visible by following customers')),
        ],
        string='Privacy', required=True,
        default='employees',
        help="Holds visibility of the tasks or issues that belong to the current vanbanden:\n"
                "- On invitation only: Employees may only see the followed vanbanden, tasks or issues\n"
                "- Visible by all employees: Employees may see all vanbanden, tasks or issues\n"
                "- Visible by following customers: employees see everything;\n"
                "   if website is activated, portal users may see vanbanden, tasks or issues followed by\n"
                "   them or by someone of their company\n")
    doc_count = fields.Integer(compute='_compute_attached_docs_count', string="Number of documents attached")
    date_start = fields.Date(string='Start Date')
    date = fields.Date(string='Expiration Date', index=True, track_visibility='onchange')

    _sql_constraints = [
        ('vanbanden_date_greater', 'check(date >= date_start)', 'Error! vanbanden start-date must be lower than vanbanden end-date.')
    ]

    @api.multi
    def map_tasks(self, new_vanbanden_id):
        """ copy and map tasks from old to new vanbanden """
        tasks = self.env['vanbanden.task']
        for task in self.tasks:
            # preserve task name and stage, normally altered during copy
            defaults = {'stage_id': task.stage_id.id,
                        'name': task.name}
            tasks += task.copy(defaults)
        return self.browse(new_vanbanden_id).write({'tasks': [(6, 0, tasks.ids)]})

    @api.multi
    def copy(self, default=None):
        if default is None:
            default = {}
        self = self.with_context(active_test=False)
        if not default.get('name'):
            default['name'] = _("%s (copy)") % (self.name)
        vanbanden = super(Vanbanden, self).copy(default)
        for follower in self.message_follower_ids:
            vanbanden.message_subscribe(partner_ids=follower.partner_id.ids, subtype_ids=follower.subtype_ids.ids)
        self.map_tasks(vanbanden.id)
        return vanbanden

    @api.model
    def create(self, vals):

        ir_values = self.env['ir.values'].get_default('vanbanden.config.settings', 'generate_vanbanden_alias')
        if ir_values:
            vals['alias_name'] = vals.get('alias_name') or vals.get('name')
        # Prevent double vanbanden creation when 'use_tasks' is checked
        self = self.with_context(vanbanden_creation_in_progress=True, mail_create_nosubscribe=True)
        return super(Vanbanden, self).create(vals)

    @api.multi
    def write(self, vals):
        # if alias_model has been changed, update alias_model_id accordingly
        if vals.get('alias_model'):
            vals['alias_model_id'] = self.env['ir.model'].search([
                ('model', '=', vals.get('alias_model', 'vanbanden.task'))
            ], limit=1).id
        res = super(Vanbanden, self).write(vals)
        if 'active' in vals:
            # archiving/unarchiving a vanbanden does it on its tasks, too
            self.with_context(active_test=False).mapped('tasks').write({'active': vals['active']})
        return res

    @api.multi
    def toggle_favorite(self):
        favorite_vanbandens = not_fav_vanbandens = self.env['vanbanden.vanbanden'].sudo()
        for vanbanden in self:
            if self.env.user in vanbanden.favorite_user_ids:
                favorite_vanbandens |= vanbanden
            else:
                not_fav_vanbandens |= vanbanden

        # Vanbanden User has no write access for vanbanden.
        not_fav_vanbandens.write({'favorite_user_ids': [(4, self.env.uid)]})
        favorite_vanbandens.write({'favorite_user_ids': [(3, self.env.uid)]})

    @api.multi
    def close_dialog(self):
        return {'type': 'ir.actions.act_window_close'}


class Task(models.Model):
    _name = "vanbanden.task"
    _description = u"Văn bản đến"
    _date_name = "date_start"
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _mail_post_access = 'read'
    _order = "priority desc, sequence, date_start, name, id"

    @api.model
    def default_get(self, field_list):
        """ Set 'date_assign' if user_id is set. """
        result = super(Task, self).default_get(field_list)
        if 'user_id' in result:
            result['date_assign'] = fields.Datetime.now()
        return result

    @api.model
    def default_dapartment_code(self):
         employee = self.env['hr.employee'].search([('user_id', '=', self.env.uid)])
         code = ''
         if employee:
            code = employee[0].department_id.code

         self._cr.execute('SELECT MAX(id) FROM vanbanden_task')
         max_id = self.env.cr.dictfetchall()
         if max_id[0]['max']:
             id = max_id[0]['max'] + 1
         else:
             id = 1
         return '{}{}'.format('VBĐ/',id)

    def _get_default_partner(self):
        if 'default_vanbanden_id' in self.env.context:
            default_vanbanden_id = self.env['vanbanden.vanbanden'].browse(self.env.context['default_vanbanden_id'])
            return default_vanbanden_id.exists().partner_id

    def _get_default_stage_id(self):
        """ Gives default stage_id """
        vanbanden_id = self.env.context.get('default_vanbanden_id')
        if not vanbanden_id:
            return False
        return self.stage_find(vanbanden_id, [('fold', '=', False)])

    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        search_domain = [('id', 'in', stages.ids)]
        if 'default_vanbanden_id' in self.env.context:
            search_domain = ['|', ('vanbanden_ids', '=', self.env.context['default_vanbanden_id'])] + search_domain

        stage_ids = stages._search(search_domain, order=order, access_rights_uid=SUPERUSER_ID)
        return stages.browse(stage_ids)

    @api.model
    def check_enable_edit_y_kien_lanh_dao(self):
        if self.is_chanhvp(self.stage_id.id):
            #current_login_uid = self.env.context['uid']
            current_login_uid = self.env.uid
            user = self.env['res.users'].browse(current_login_uid)
            return user.has_group('vanbanden.group_vanbanden_thu_ky_cm')
        return False


    active = fields.Boolean(default=True)
    name = fields.Char(string='Task Title', track_visibility='always', required=True, index=True)
    description = fields.Html(string='Description')
    priority = fields.Selection([
            ('0','Normal'),
            ('1','High')
        ], default='0', index=True)
    sequence = fields.Integer(string='Sequence', index=True, default=100000,
        help="Gives the sequence order when displaying a list of tasks.")
    stage_id = fields.Many2one('vanbanden.task.type', string='Stage', track_visibility='onchange', index=True,
        default=_get_default_stage_id, group_expand='_read_group_stage_ids',
        domain="[('vanbanden_ids', '=', vanbanden_id)]", copy=False)
    tag_ids = fields.Many2many('vanbanden.tags', string='Tags', oldname='categ_ids')
    kanban_state = fields.Selection([
            ('normal', 'In Progress'),
            ('done', 'Ready for next stage'),
            ('blocked', 'Blocked')
        ], string='Kanban State',
        default='normal',
        track_visibility='onchange',
        required=True, copy=False,
        help="A task's kanban state indicates special situations affecting it:\n"
             " * Normal is the default situation\n"
             " * Blocked indicates something is preventing the progress of this task\n"
             " * Ready for next stage indicates the task is ready to be pulled to the next stage")
    create_date = fields.Datetime(index=True , copy=False, readonly=True)
    write_date = fields.Datetime(index=True)  #not displayed in the view but it might be useful with base_action_rule module (and it needs to be defined first for that)
    date_start = fields.Datetime(string='Starting Date',
    default=fields.Datetime.now,
    index=True, copy=False)
    date_end = fields.Datetime(string='Ending Date', index=True, copy=False)
    date_assign = fields.Datetime(string='Assigning Date', index=True, copy=False, readonly=True)
    date_vanbanden = fields.Date(string='Ngay van ban den', index=True, copy=False)
    date_vanban = fields.Date(string='Ngay van ban', index=True, copy=False)
    noi_nhan = fields.Many2one('hr.department',
                                       string='Noi nhan',
                                       required=False)
    date_deadline = fields.Date(string='Deadline', index=True, copy=False)
    # tungnt start
    trich_yeu = fields.Html(string='Trich yeu to trinh')
    noi_luu = fields.Char(string='Noi luu')
    loai_so_id = fields.Many2one('vanbanden.field',
                                  string='Loai so',
                                  required=False,
                                  default=1, track_visibility='always')

    project_id = fields.Many2one('vanbanden.project',
                                 string='Project',
                                 required=False)
    support_ids = fields.Many2many('res.users',  'vanbanden_support_task_rel', 'vanbanden_task_id', 'user_id', string='Nguoi ho tro', track_visibility='onchange')
    enable_edit_y_kien_lanh_dao = fields.Boolean(default=False, readOnly=True)
    y_kien = fields.Html(string='Y kien VP')

    code = fields.Char(string='Code', required=True, index=True, default=default_dapartment_code)
    create_uid = fields.Many2one('res.users',
                              string='Nguoi tao',
                              default=lambda self: self.env.uid,
                              index=True, track_visibility='always' , readonly=True)


    vanbanden_related_ids = fields.Many2many('vanbanden.task','vanbanden_task_rel', 'vanbanden_task_id', 'vanbanden_task_related_id', string='Van ban lien quan')

    tra_lai_ban_goc = fields.Boolean(default=False,
                            help="Tra lai ban goc.")

    ho_so_kem_theo = fields.Char(string='Ho so kem theo', required=False, index=True, default='')
    files_ids = fields.Many2many('thmdocument.file', 'vanbanden_file_task_rel', 'vanbanden_task_id', 'file_id',
                                string='Ho So')
    # tungnt end

    date_last_stage_update = fields.Datetime(string='Last Stage Update',
        default=fields.Datetime.now,
        index=True,
        copy=False,
        readonly=True)
    vanbanden_id = fields.Many2one('vanbanden.vanbanden',
        string='Vanbanden',
        default=lambda self: self.env.context.get('default_vanbanden_id'),
        index=True,
        track_visibility='onchange',
        change_default=True)
    notes = fields.Text(string='Notes')
    planned_hours = fields.Float(string='Initially Planned Hours', help='Estimated time to do the task, usually set by the vanbanden manager when the task is in draft state.')
    remaining_hours = fields.Float(string='Remaining Hours', digits=(16,2), help="Total remaining time, can be re-estimated periodically by the assignee of the task.")

    # @api.multi
    # def read(self, vals):
    #     res = super(Task, self).fields_view_get(view_id=None, view_type='form', toolbar=True, submenu=False)
    #
    #     eview = etree.fromstring(res['arch'])
    #
    #     for node in eview.xpath("//field[@name='user_id']"):
    #         user_filter = "[('id', 'in',[1,6] )]"
    #         node.set('domain', user_filter)
    #
    #     return super(Task, self).read()

    @api.model
    def _getUserIdByGroup_base_on_Stage(self):
        # full_url = http.request.httprequest.full_path
        # parsed = urlparse.urlparse(full_url)
        # vanbanden_id = urlparse.parse_qs(parsed.query)['id']
        # current_vanbanden = self.env['vanbanden.task'].browse(vanbanden_id)
        user_array = []

        # current_stage_id = current_vanbanden.stage_id.id
        vanbanden_group = None

        # if(self.is_vanthu(current_stage_id)) :
        #     vanbanden_group = self.env.ref('vanbanden.group_vanbanden_van_thu')
        # elif(self.is_chanhvp(current_stage_id)):
        #     vanbanden_group = self.env.ref('vanbanden.group_vanbanden_thu_ky_cm')
        # elif(self.is_lanhdao(current_stage_id)):
        #     vanbanden_group = self.env.ref('vanbanden.group_vanbanden_lanh_dao')
        vanbanden_group = self.env.ref('vanbanden.group_vanbanden_user')
        if(vanbanden_group):
            for user in vanbanden_group.users :
                user_array.append(user.id)

        return [('id', 'in', user_array)]

    user_id = fields.Many2one('res.users',
        string='Assigned to',
        default=lambda self: self.env.uid,
        index=True, track_visibility='always',
        domain = _getUserIdByGroup_base_on_Stage)
    partner_id = fields.Many2one('res.partner',
        string='Customer',
        default=_get_default_partner)
    manager_id = fields.Many2one('res.users', string='Vanbanden Manager', related='vanbanden_id.user_id', readonly=True)
    company_id = fields.Many2one('res.company',
        string='Company',
        default=lambda self: self.env['res.company']._company_default_get())
    color = fields.Integer(string='Color Index')
    user_email = fields.Char(related='user_id.email', string='User Email', readonly=True)
    attachment_ids = fields.One2many('ir.attachment', 'res_id', domain=lambda self: [('res_model', '=', self._name)], auto_join=True, string='Attachments')
    # In the domain of displayed_image_id, we couln't use attachment_ids because a one2many is represented as a list of commands so we used res_model & res_id
    displayed_image_id = fields.Many2one('ir.attachment', domain="[('res_model', '=', 'vanbanden.task'), ('res_id', '=', id), ('mimetype', 'ilike', 'image')]", string='Displayed Image')
    legend_blocked = fields.Char(related='stage_id.legend_blocked', string='Kanban Blocked Explanation', readonly=True)
    legend_done = fields.Char(related='stage_id.legend_done', string='Kanban Valid Explanation', readonly=True)
    legend_normal = fields.Char(related='stage_id.legend_normal', string='Kanban Ongoing Explanation', readonly=True)


    @api.onchange('vanbanden_id')
    def _onchange_vanbanden(self):
        if self.vanbanden_id:
            self.partner_id = self.vanbanden_id.partner_id
            self.stage_id = self.stage_find(self.vanbanden_id.id, [('fold', '=', False)])
        else:
            self.stage_id = False


    @api.model
    def check_user_is_chanhvp(self , user):
        if (user):
            return user.has_group('vanbanden.group_vanbanden_thu_ky_cm')
        return False

    @api.multi
    def get_chu_tri_domain(self):
        user_array = []

        current_stage_id = self.stage_id.id
        vanbanden_group = None

        if (self.is_vanthu(current_stage_id)):
            vanbanden_group = self.env.ref('vanbanden.group_vanbanden_van_thu')
        elif (self.is_chanhvp(current_stage_id)):
            vanbanden_group = self.env.ref('vanbanden.group_vanbanden_thu_ky_cm')
        elif (self.is_lanhdao(current_stage_id)):
            vanbanden_group = self.env.ref('vanbanden.group_vanbanden_lanh_dao')

        if (not vanbanden_group):
            vanbanden_group = self.env.ref('vanbanden.group_vanbanden_user')

        for user in vanbanden_group.users:
            user_array.append(user.id)

        return user_array

    @api.multi
    def get_domain_useer_id(self):
        user_array = self.get_chu_tri_domain()
        return {'domain': {'user_id': [('id', 'in', user_array)]}}

        # lids = [1,6]
        # return {'domain': {'user_id': [('id', 'in', lids)]}}

    @api.model
    def check_user_is_lanh_dao(self , user):
        if (user):
            return user.has_group('vanbanden.group_vanbanden_lanh_dao')
        return False

    @api.model
    def check_user_is_van_thu(self , user):
        if (user):
            return user.has_group('vanbanden.group_vanbanden_van_thu')
        return False


    @api.multi
    def is_lanhdao(self, sid):
        return sid == 3

    @api.multi
    def is_vanthu(self, sid):
        return sid == 1

    @api.multi
    def is_chanhvp(self, sid):
        return sid == 2


    # @api.onchange('stage_id')
    # def _onchange_stage(self):
    #     user_array = self.get_chu_tri_domain()
    #     return {'domain': {'user_id': [('id', 'in', user_array)]}}

    @api.onchange('user_id')
    def _onchange_user(self):
        if self.user_id:
            self.date_start = fields.Datetime.now()

            # stage_id = self.stage_id.id;
            # assigned_user = self.env['res.users'].browse(self.user_id.id)
            # if ((self.is_vanthu(stage_id) and self.check_user_is_van_thu(assigned_user))
            #     or (self.is_chanhvp(stage_id) and self.check_user_is_chanhvp(assigned_user))
            #     ):
            #     self.date_start = fields.Datetime.now()
            # else:
            #     raise ValidationError(u'Người chủ trì không thuộc giai đoạn này')
            #     current_vanbanden = self.env['vanbanden.task'].browse(self.id)
            #     self.user_id = current_vanbanden.user_id

    @api.multi
    def copy(self, default=None):
        if default is None:
            default = {}
        if not default.get('name'):
            default['name'] = _("%s (copy)") % self.name
        if 'remaining_hours' not in default:
            default['remaining_hours'] = self.planned_hours
        return super(Task, self).copy(default)

    @api.constrains('date_start', 'date_end')
    def _check_dates(self):
        if any(self.filtered(lambda task: task.date_start and task.date_end and task.date_start > task.date_end)):
            raise ValidationError(_('Error ! Task starting date must be lower than its ending date.'))

    # Override view according to the company definition
    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        # read uom as admin to avoid access rights issues, e.g. for portal/share users,
        # this should be safe (no context passed to avoid side-effects)
        obj_tm = self.env.user.company_id.vanbanden_time_mode_id
        tm = obj_tm and obj_tm.name or 'Hours'

        res = super(Task, self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu)

        # read uom as admin to avoid access rights issues, e.g. for portal/share users,
        # this should be safe (no context passed to avoid side-effects)
        obj_tm = self.env.user.company_id.vanbanden_time_mode_id
        # using get_object to get translation value
        uom_hour = self.env.ref('product.product_uom_hour', False)
        if not obj_tm or not uom_hour or obj_tm.id == uom_hour.id:
            return res

        eview = etree.fromstring(res['arch'])

        # if the vanbanden_time_mode_id is not in hours (so in days), display it as a float field
        def _check_rec(eview):
            if eview.attrib.get('widget', '') == 'float_time':
                eview.set('widget', 'float')
            for child in eview:
                _check_rec(child)
            return True

        _check_rec(eview)

        res['arch'] = etree.tostring(eview)

        # replace reference of 'Hours' to 'Day(s)'
        for f in res['fields']:
            # TODO this NOT work in different language than english
            # the field 'Initially Planned Hours' should be replaced by 'Initially Planned Days'
            # but string 'Initially Planned Days' is not available in translation
            if 'Hours' in res['fields'][f]['string']:
                res['fields'][f]['string'] = res['fields'][f]['string'].replace('Hours', obj_tm.name)
        return res

    @api.model
    def get_empty_list_help(self, help):
        self = self.with_context(
            empty_list_help_id=self.env.context.get('default_vanbanden_id'),
            empty_list_help_model='vanbanden.vanbanden',
            empty_list_help_document_name=_("tasks")
        )
        return super(Task, self).get_empty_list_help(help)

    # ----------------------------------------
    # Case management
    # ----------------------------------------

    def stage_find(self, section_id, domain=[], order='sequence'):
        """ Override of the base.stage method
            Parameter of the stage search taken from the lead:
            - section_id: if set, stages must belong to this section or
              be a default stage; if not set, stages must be default
              stages
        """
        # collect all section_ids
        section_ids = []
        if section_id:
            section_ids.append(section_id)
        section_ids.extend(self.mapped('vanbanden_id').ids)
        search_domain = []
        if section_ids:
            search_domain = [('|')] * (len(section_ids) - 1)
            for section_id in section_ids:
                search_domain.append(('vanbanden_ids', '=', section_id))
        search_domain += list(domain)
        # perform search, return the first found
        return self.env['vanbanden.task.type'].search(search_domain, order=order, limit=1).id

    # ------------------------------------------------
    # CRUD overrides
    # ------------------------------------------------
    def check_int(self, s):

        str_input = str(s)
        if (len(str_input) == 0):
            return False
        if str_input[0] in ('-', '+'):
            return str_input[1:].isdigit()
        return str_input.isdigit()
    @api.model
    def my_function(self, task):
        # self._cr.execute("SELECT * FROM mail_message msg INNER JOIN mail_tracking_value track ON msg.id = track.mail_message_id WHERE msg.res_id = %s AND msg.message_type = 'notification'", (task.get('id'),))
        # mail_message = self.env.cr.dictfetchall()
        # _logger.info('tungnt save abc query_results %s', pprint.pformat(mail_message))
        # # mail_message = self.env['mail.message'].search([('res_id', '=', task.get('id')), ('message_type', '=', 'notification')])
        # # _logger.info('tungnt save abc result %s', pprint.pformat(mail_message))
        # data = []
        # for msg in mail_message:
        #     data.append(msg.get('id'))
        # return json.dumps(data)
        users = {}
        nodes = []
        edges = []
        data = []
        if(self.check_int(task.get('id'))) :
            self._cr.execute("SELECT * FROM mail_message msg WHERE msg.res_id = %s AND msg.message_type = 'notification' AND msg.model = 'vanbanden.task' AND msg.create_uid != 1 ORDER BY msg.create_date ASC", (task.get('id'),))
            mail_message = self.env.cr.dictfetchall()

            i = 0
            previous_user_id = 0;
            for msg in mail_message:
                self._cr.execute("SELECT * FROM mail_tracking_value tracking WHERE tracking.mail_message_id = %s ",(msg.get('id'),))
                mail_tracking_values = self.env.cr.dictfetchall()
                # _logger.info('tungnt save mail_tracking_value %s', pprint.pformat(mail_tracking_value))

                for track in mail_tracking_values:
                    # if(track.get('field') == 'stage_id'):
                    #     task_stage = self.env['vanbanden.task.type'].search([('id', '=', track.get('new_value_integer'))])
                    #     nodes.append({'id': i, 'label': task_stage[0].name})
                    if (track.get('field') == 'user_id'):
                        current_user_id = track.get('new_value_integer')
                    elif (track.get('field') == 'stage_id'):
                        current_stage_id = track.get('new_value_integer')

                if(current_user_id != previous_user_id): #or current_stage_id != previous_stage_id):
                    assigned_user = self.env['res.users'].browse(current_user_id)
                    _logger.info('tungnt save assigned_user %s', pprint.pformat(assigned_user))
                    if not current_user_id in users:
                        users[current_user_id] = assigned_user.name;
                        nodes.append({'id': current_user_id, 'label': assigned_user.name})
                    if (i > 0):
                        #if (current_user_id != previous_user_id):
                        #   label = u'Chuyển'
                        #else:
                        #    label = u'Cập nhật'
                        label = u'Chuyển'
                        edges.append({'from': previous_user_id, 'to': current_user_id, 'label': u'{}.{}'.format(i, label)})
                    i = i + 1

                previous_user_id = current_user_id
                #previous_stage_id = current_stage_id

        #s = '},{'.join(u'"id":{}, "label":"{}"'.format(key, val) for key, val in nodes.items())
        #s = '[{"nodes":[{'+ s +'}] , "edges":' + json.dumps(edges) + '}]'
        data.append({'nodes' : nodes, 'edges' : edges})
        return json.dumps(data)

    @api.model
    def create(self, vals):
        sid = vals.get('stage_id')
        if not self.is_vanthu(sid):
            raise ValidationError(u'Không được phép tạo trái tuyến!')
            return False

        # context: no_log, because subtype already handle this
        context = dict(self.env.context, mail_create_nolog=True)

        # for default stage
        if vals.get('vanbanden_id') and not context.get('default_vanbanden_id'):
            context['default_vanbanden_id'] = vals.get('vanbanden_id')
        # user_id change: update date_assign
        if vals.get('user_id'):
            vals['date_assign'] = fields.Datetime.now()
        task = super(Task, self.with_context(context)).create(vals)

        # add follower
        task.message_subscribe_users(task.support_ids.ids)

        _logger.info('tungnt save result %s', pprint.pformat(task))

        # self.open_task_modal(context)
        return task



    @api.multi
    def unlink(self):
        # current_login_uid = self.env.context['uid']
        # if (self.user_id.id
        #     and not (self.user_id.id == current_login_uid)):
        #     raise ValidationError(u'Không được phép thay đổi!')
        #     return False
        res = super(Task, self).unlink()
        return res

    @api.multi
    def write(self, vals):

        # if (self.user_id.id
        #     and not (self.user_id.id == current_login_uid)
        #     and not (len(vals) == 1 and ('message_follower_ids' in vals.keys()))): #right after update, system automatically call to update message_follower_ids
        #     raise ValidationError(u'Không được phép thay đổi!')
        #     return False

        current_login_uid = self.env.context['uid']
        current_user = self.env['res.users'].browse(current_login_uid)

        if ('y_kien' in vals): # check if y_kien was edited
            if(vals.get('y_kien') != '<p><br></p>'): # default of html editor if it is enable is  '<p><br></p>'
                last_sid = self.stage_id.id
                if(self.is_chanhvp(last_sid) and not self.check_user_is_chanhvp(current_user)) :
                    raise ValidationError(u'Không được phép thay đổi ý kiến lãnh đạo!')
                    return False

        check = False
        if(len(vals) == 1 and 'message_follower_ids' in vals ):
            check = True
        elif(len(vals) == 1 and 'sequence' in vals ):
            check = True
        else:
            check = True
            if (current_login_uid != self.user_id.id):
                raise ValidationError(u'Không được phép thay đổi!')
                return False



        # if(len(vals) >= 1 and (not 'message_follower_ids' in vals or not 'sequence' in vals ) ):
        #     if (current_login_uid != self.user_id.id):
        #         raise ValidationError(u'Không được phép thay đổi!')
        #         return False


        now = fields.Datetime.now()

        if vals.get('user_id'):
            vals['date_assign'] = now



        # stage change: update date_last_stage_update
        if 'stage_id' in vals:
            # resource = self.env['resource.resource'].search([('user_id', '=', self.env.uid)])
            employee = self.env['hr.employee'].search([('user_id', '=', self.create_uid.id)])
            _logger.info('tungnt employee %s', pprint.pformat(employee))
            sid = vals.get('stage_id')
            last_sid = self.stage_id.id

            vals['date_last_stage_update'] = now
            # reset kanban state when changing stage
            if 'kanban_state' not in vals:
                vals['kanban_state'] = 'normal'

        # if ('y_kien' in vals) and not self.check_enable_edit_y_kien_lanh_dao():
        #     raise ValidationError(u'Không có quyền sửa ý kiến của lãnh đạo!')
        #     return False

        # user_id change: update date_assign


        result = super(Task, self).write(vals)

        # add follower
        if vals.get('support_ids'):
            self.message_subscribe_users([support['id'] for support in self.resolve_2many_commands('support_ids', vals['support_ids'], ['id'])])

        return result



    # ---------------------------------------------------
    # Mail gateway
    # ---------------------------------------------------

    @api.multi
    def _track_template(self, tracking):
        res = super(Task, self)._track_template(tracking)
        test_task = self[0]
        changes, tracking_value_ids = tracking[test_task.id]
        if 'stage_id' in changes and test_task.stage_id.mail_template_id:
            res['stage_id'] = (test_task.stage_id.mail_template_id, {'composition_mode': 'mass_mail'})
        return res

    @api.multi
    def _track_subtype(self, init_values):
        self.ensure_one()
        if 'kanban_state' in init_values and self.kanban_state == 'blocked':
            return 'vanbanden.mt_task_blocked'
        elif 'kanban_state' in init_values and self.kanban_state == 'done':
            return 'vanbanden.mt_task_ready'
        elif 'user_id' in init_values and self.user_id:  # assigned -> new
            return 'vanbanden.mt_task_new'
        elif 'stage_id' in init_values and self.stage_id and self.stage_id.sequence <= 1:  # start stage -> new
            return 'vanbanden.mt_task_new'
        elif 'stage_id' in init_values:
            return 'vanbanden.mt_task_stage'
        return super(Task, self)._track_subtype(init_values)

    @api.multi
    def _notification_recipients(self, message, groups):
        """ Handle vanbanden users and managers recipients that can convert assign
        tasks and create new one directly from notification emails. """
        groups = super(Task, self)._notification_recipients(message, groups)

        self.ensure_one()
        if not self.user_id:
            take_action = self._notification_link_helper('assign')
            vanbanden_actions = [{'url': take_action, 'title': _(u'Tôi tiếp nhận nó')}]
        else:
            new_action_id = self.env.ref('vanbanden.action_view_task').id
            new_action = self._notification_link_helper('new', action_id=new_action_id)
            vanbanden_actions = [{'url': new_action, 'title': _(u'Văn bản đến mới')}]

        new_group = (
            'group_vanbanden_user', lambda partner: bool(partner.user_ids) and any(user.has_group('vanbanden.group_vanbanden_user') for user in partner.user_ids), {
                'actions': vanbanden_actions,
            })

        return [new_group] + groups

    @api.model
    def message_get_reply_to(self, res_ids, default=None):
        """ Override to get the reply_to of the parent vanbanden. """
        tasks = self.sudo().browse(res_ids)
        vanbanden_ids = tasks.mapped('vanbanden_id').ids
        aliases = self.env['vanbanden.vanbanden'].message_get_reply_to(vanbanden_ids, default=default)
        return {task.id: aliases.get(task.vanbanden_id.id, False) for task in tasks}

    @api.multi
    def email_split(self, msg):
        email_list = tools.email_split((msg.get('to') or '') + ',' + (msg.get('cc') or ''))
        # check left-part is not already an alias
        aliases = self.mapped('vanbanden_id.alias_name')
        return filter(lambda x: x.split('@')[0] not in aliases, email_list)

    @api.model
    def message_new(self, msg, custom_values=None):
        """ Override to updates the document according to the email. """
        if custom_values is None:
            custom_values = {}
        defaults = {
            'name': msg.get('subject'),
            'planned_hours': 0.0,
            'partner_id': msg.get('author_id')
        }
        defaults.update(custom_values)

        res = super(Task, self).message_new(msg, custom_values=defaults)
        task = self.browse(res)
        email_list = task.email_split(msg)
        partner_ids = filter(None, task._find_partner_from_emails(email_list, force_create=False))
        task.message_subscribe(partner_ids)
        return res

    @api.multi
    def message_update(self, msg, update_vals=None):
        """ Override to update the task according to the email. """
        if update_vals is None:
            update_vals = {}
        maps = {
            'cost': 'planned_hours',
        }
        for line in msg['body'].split('\n'):
            line = line.strip()
            res = tools.command_re.match(line)
            if res:
                match = res.group(1).lower()
                field = maps.get(match)
                if field:
                    try:
                        update_vals[field] = float(res.group(2).lower())
                    except (ValueError, TypeError):
                        pass

        email_list = self.email_split(msg)
        partner_ids = filter(None, self._find_partner_from_emails(email_list, force_create=False))
        self.message_subscribe(partner_ids)
        return super(Task, self).message_update(msg, update_vals=update_vals)

    @api.multi
    def message_get_suggested_recipients(self):
        recipients = super(Task, self).message_get_suggested_recipients()
        for task in self.filtered('partner_id'):
            reason = _('Customer Email') if task.partner_id.email else _('Customer')
            task._message_add_suggested_recipient(recipients, partner=task.partner_id, reason=reason)
        return recipients

    @api.multi
    def message_get_email_values(self, notif_mail=None):
        res = super(Task, self).message_get_email_values(notif_mail=notif_mail)
        headers = {}
        if res.get('headers'):
            try:
                headers.update(safe_eval(res['headers']))
            except Exception:
                pass
        if self.vanbanden_id:
            current_objects = filter(None, headers.get('X-Odoo-Objects', '').split(','))
            current_objects.insert(0, 'vanbanden.vanbanden-%s, ' % self.vanbanden_id.id)
            headers['X-Odoo-Objects'] = ','.join(current_objects)
        if self.tag_ids:
            headers['X-Odoo-Tags'] = ','.join(self.tag_ids.mapped('name'))
        res['headers'] = repr(headers)
        return res
    _sql_constraints = [
        ('code_uniq', 'unique (code)', u'Mã văn bản đã có!'),
    ]

class AccountAnalyticAccount(models.Model):

    _inherit = 'account.analytic.account'
    _description = 'Analytic Account'

    vanbanden_use_tasks = fields.Boolean(string=u'Văn bản đến sử dụng',
                               help=u"Tích vào ô này để quản lý các hoạt động trong văn bản này")

    vanbanden_company_uom_id = fields.Many2one('product.uom', related='company_id.vanbanden_time_mode_id', string="Company UOM")
    vanbanden_ids = fields.One2many('vanbanden.vanbanden', 'analytic_account_id', string=u'Loại văn bản')
    vanbanden_count = fields.Integer(compute='_compute_vanbanden_count', string='Vanbanden Count')

    def _compute_vanbanden_count(self):
        for account in self:
            account.vanbanden_count = len(account.with_context(active_test=False).vanbanden_ids)

    @api.model
    def _trigger_vanbanden_creation(self, vals):
        '''
        This function is used to decide if a vanbanden needs to be automatically created or not when an analytic account is created. It returns True if it needs to be so, False otherwise.
        '''
        return vals.get('vanbanden_use_tasks') and 'vanbanden_creation_in_progress' not in self.env.context

    @api.multi
    def vanbanden_create(self, vals):
        '''
        This function is called at the time of analytic account creation and is used to create a vanbanden automatically linked to it if the conditions are meet.
        '''
        self.ensure_one()
        Vanbanden = self.env['vanbanden.vanbanden']
        vanbanden = Vanbanden.with_context(active_test=False).search([('analytic_account_id', '=', self.id)])
        if not vanbanden and self._trigger_vanbanden_creation(vals):
            vanbanden_values = {
                'name': vals.get('name'),
                'analytic_account_id': self.id,
                'vanbanden_use_tasks': True
            }
            return Vanbanden.create(vanbanden_values).id
        return False

    @api.model
    def create(self, vals):
        analytic_account = super(AccountAnalyticAccount, self).create(vals)
        analytic_account.vanbanden_create(vals)
        return analytic_account

    @api.multi
    def write(self, vals):
        vals_for_vanbanden = vals.copy()
        for account in self:
            if not vals.get('name'):
                vals_for_vanbanden['name'] = account.name
            account.vanbanden_create(vals_for_vanbanden)
        return super(AccountAnalyticAccount, self).write(vals)

    @api.multi
    def unlink(self):
        vanbandens = self.env['vanbanden.vanbanden'].search([('analytic_account_id', 'in', self.ids)])
        has_tasks = self.env['vanbanden.task'].search_count([('vanbanden_id', 'in', vanbandens.ids)])
        if has_tasks:
            raise UserError(_('Please remove existing tasks in the vanbanden linked to the accounts you want to delete.'))
        return super(AccountAnalyticAccount, self).unlink()

    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100):
        if args is None:
            args = []
        if self.env.context.get('current_model') == 'vanbanden.vanbanden':
            return self.search(args + [('name', operator, name)], limit=limit).name_get()

        return super(AccountAnalyticAccount, self).name_search(name, args=args, operator=operator, limit=limit)

    @api.multi
    def vanbandens_action(self):
        vanbandens = self.with_context(active_test=False).mapped('vanbanden_ids')
        result = {
            "type": "ir.actions.act_window",
            "res_model": "vanbanden.vanbanden",
            "views": [[False, "tree"], [False, "form"]],
            "domain": [["id", "in", vanbandens.ids]],
            "context": {"create": False},
            "name": "Vanbandens",
        }
        if len(vanbandens) == 1:
            result['views'] = [(False, "form")]
            result['res_id'] = vanbandens.id
        else:
            result = {'type': 'ir.actions.act_window_close'}
        return result

class VanbandenTags(models.Model):
    """ Tags of vanbanden's tasks (or issues) """
    _name = "vanbanden.tags"
    _description = u"Các thẻ tag của văn bản,..."

    name = fields.Char(required=True)
    color = fields.Integer(string=u'Chỉ số màu')

    _sql_constraints = [
        ('name_uniq', 'unique (name)', u"Tag đã tồn tại!"),
    ]
