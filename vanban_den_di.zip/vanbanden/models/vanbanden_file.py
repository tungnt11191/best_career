# -*- coding: utf-8 -*-
from odoo import models, fields, api

from odoo.exceptions import UserError, ValidationError
#Import logger
import logging
#Get the logger
_logger = logging.getLogger(__name__)

#External import
import datetime

class vanbanden_file(models.Model):
    _inherit = 'thmdocument.file'
    vanbanden_task_ids = fields.Many2many('vanbanden.task', 'vanbanden_file_task_rel', 'file_id',
                                       'vanbanden_task_id', string='Task')
