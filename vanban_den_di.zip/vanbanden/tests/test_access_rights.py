# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.addons.vanbanden.tests.test_vanbanden_base import TestVanbandenBase
from odoo.exceptions import AccessError
from odoo.tools import mute_logger


class TestPortalVanbandenBase(TestVanbandenBase):

    def setUp(self):
        super(TestPortalVanbandenBase, self).setUp()
        self.user_noone = self.env['res.users'].with_context({'no_reset_password': True, 'mail_create_nosubscribe': True}).create({
            'name': 'Noemie NoOne',
            'login': 'noemie',
            'email': 'n.n@example.com',
            'signature': '--\nNoemie',
            'notify_email': 'always',
            'groups_id': [(6, 0, [])]})

        self.task_3 = self.env['vanbanden.task'].with_context({'mail_create_nolog': True}).create({
            'name': 'Test3', 'user_id': self.user_portal.id, 'vanbanden_id': self.vanbanden_pigs.id})
        self.task_4 = self.env['vanbanden.task'].with_context({'mail_create_nolog': True}).create({
            'name': 'Test4', 'user_id': self.user_public.id, 'vanbanden_id': self.vanbanden_pigs.id})
        self.task_5 = self.env['vanbanden.task'].with_context({'mail_create_nolog': True}).create({
            'name': 'Test5', 'user_id': False, 'vanbanden_id': self.vanbanden_pigs.id})
        self.task_6 = self.env['vanbanden.task'].with_context({'mail_create_nolog': True}).create({
            'name': 'Test5', 'user_id': False, 'vanbanden_id': self.vanbanden_pigs.id})


class TestPortalVanbanden(TestPortalVanbandenBase):

    @mute_logger('odoo.addons.base.ir.ir_model')
    def test_employee_vanbanden_access_rights(self):
        pigs = self.vanbanden_pigs

        pigs.write({'privacy_visibility': 'employees'})
        # Do: Alfred reads vanbanden -> ok (employee ok employee)
        pigs.sudo(self.user_vanbandenuser).read(['user_id'])
        # Test: all vanbanden tasks visible
        tasks = self.env['vanbanden.task'].sudo(self.user_vanbandenuser).search([('vanbanden_id', '=', pigs.id)])
        test_task_ids = set([self.task_1.id, self.task_2.id, self.task_3.id, self.task_4.id, self.task_5.id, self.task_6.id])
        self.assertEqual(set(tasks.ids), test_task_ids,
                        'access rights: vanbanden user cannot see all tasks of an employees vanbanden')
        # Do: Bert reads vanbanden -> crash, no group
        self.assertRaises(AccessError, pigs.sudo(self.user_noone).read, ['user_id'])
        # Do: Donovan reads vanbanden -> ko (public ko employee)
        self.assertRaises(AccessError, pigs.sudo(self.user_public).read, ['user_id'])
        # Do: vanbanden user is employee and can create a task
        tmp_task = self.env['vanbanden.task'].sudo(self.user_vanbandenuser).with_context({'mail_create_nolog': True}).create({
            'name': 'Pigs task',
            'vanbanden_id': pigs.id})
        tmp_task.sudo(self.user_vanbandenuser).unlink()

    @mute_logger('odoo.addons.base.ir.ir_model')
    def test_followers_vanbanden_access_rights(self):
        pigs = self.vanbanden_pigs
        pigs.write({'privacy_visibility': 'followers'})

        # Do: Alfred reads vanbanden -> ko (employee ko followers)
        self.assertRaises(AccessError, pigs.sudo(self.user_vanbandenuser).read, ['user_id'])
        # Test: no vanbanden task visible
        tasks = self.env['vanbanden.task'].sudo(self.user_vanbandenuser).search([('vanbanden_id', '=', pigs.id)])
        self.assertEqual(tasks, self.task_1,
                         'access rights: employee user should not see tasks of a not-followed followers vanbanden, only assigned')

        # Do: Bert reads vanbanden -> crash, no group
        self.assertRaises(AccessError, pigs.sudo(self.user_noone).read, ['user_id'])

        # Do: Donovan reads vanbanden -> ko (public ko employee)
        self.assertRaises(AccessError, pigs.sudo(self.user_public).read, ['user_id'])

        pigs.message_subscribe_users(user_ids=[self.user_vanbandenuser.id])

        # Do: Alfred reads vanbanden -> ok (follower ok followers)
        prout = pigs.sudo(self.user_vanbandenuser)
        prout.invalidate_cache()
        prout.read(['user_id'])

        # Do: Donovan reads vanbanden -> ko (public ko follower even if follower)
        self.assertRaises(AccessError, pigs.sudo(self.user_public).read, ['user_id'])
        # Do: vanbanden user is follower of the vanbanden and can create a task
        self.env['vanbanden.task'].sudo(self.user_vanbandenuser.id).with_context({'mail_create_nolog': True}).create({
            'name': 'Pigs task', 'vanbanden_id': pigs.id
        })
        # not follower user should not be able to create a task
        pigs.sudo(self.user_vanbandenuser).message_unsubscribe_users(user_ids=[self.user_vanbandenuser.id])
        self.assertRaises(AccessError, self.env['vanbanden.task'].sudo(self.user_vanbandenuser).with_context({
            'mail_create_nolog': True}).create, {'name': 'Pigs task', 'vanbanden_id': pigs.id})

        # Do: vanbanden user can create a task without vanbanden
        self.assertRaises(AccessError, self.env['vanbanden.task'].sudo(self.user_vanbandenuser).with_context({
            'mail_create_nolog': True}).create, {'name': 'Pigs task', 'vanbanden_id': pigs.id})
