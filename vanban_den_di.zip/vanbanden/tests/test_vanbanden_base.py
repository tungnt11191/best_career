# -*- coding: utf-8 -*-

from odoo.addons.mail.tests.common import TestMail


class TestVanbandenBase(TestMail):

    @classmethod
    def setUpClass(cls):
        super(TestVanbandenBase, cls).setUpClass()

        user_group_employee = cls.env.ref('base.group_user')
        user_group_vanbanden_user = cls.env.ref('vanbanden.group_vanbanden_user')
        user_group_vanbanden_manager = cls.env.ref('vanbanden.group_vanbanden_manager')

        # Test users to use through the various tests
        Users = cls.env['res.users'].with_context({'no_reset_password': True})
        cls.user_vanbandenuser = Users.create({
            'name': 'Armande VanbandenUser',
            'login': 'Armande',
            'email': 'armande.vanbandenuser@example.com',
            'groups_id': [(6, 0, [user_group_employee.id, user_group_vanbanden_user.id])]
        })
        cls.user_vanbandenmanager = Users.create({
            'name': 'Bastien VanbandenManager',
            'login': 'bastien',
            'email': 'bastien.vanbandenmanager@example.com',
            'groups_id': [(6, 0, [user_group_employee.id, user_group_vanbanden_manager.id])]})

        # Test 'Pigs' vanbanden
        cls.vanbanden_pigs = cls.env['vanbanden.vanbanden'].with_context({'mail_create_nolog': True}).create({
            'name': 'Pigs',
            'privacy_visibility': 'employees',
            'alias_name': 'vanbanden+pigs',
            'partner_id': cls.partner_1.id})
        # Already-existing tasks in Pigs
        cls.task_1 = cls.env['vanbanden.task'].with_context({'mail_create_nolog': True}).create({
            'name': 'Pigs UserTask',
            'user_id': cls.user_vanbandenuser.id,
            'vanbanden_id': cls.vanbanden_pigs.id})
        cls.task_2 = cls.env['vanbanden.task'].with_context({'mail_create_nolog': True}).create({
            'name': 'Pigs ManagerTask',
            'user_id': cls.user_vanbandenmanager.id,
            'vanbanden_id': cls.vanbanden_pigs.id})

        # Test 'Goats' vanbanden, same as 'Pigs', but with 2 stages
        cls.vanbanden_goats = cls.env['vanbanden.vanbanden'].with_context({'mail_create_nolog': True}).create({
            'name': 'Goats',
            'privacy_visibility': 'followers',
            'alias_name': 'vanbanden+goats',
            'partner_id': cls.partner_1.id,
            'type_ids': [
                (0, 0, {
                    'name': 'New',
                    'sequence': 1,
                }),
                (0, 0, {
                    'name': 'Won',
                    'sequence': 10,
                })]
            })
