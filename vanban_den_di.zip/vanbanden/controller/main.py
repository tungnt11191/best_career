import re
from odoo.api import call_kw, Environment
from odoo.exceptions import AccessError, ValidationError
from odoo.http import Controller, route, request


# match private methods, to prevent their remote invocation
regex_private = re.compile(r'^(_.*|init)$')

def check_method_name(name):
    """ Raise an ``AccessError`` if ``name`` is a private method name. """
    if regex_private.match(name):
        raise AccessError(_('Private methods (such as %s) cannot be called remotely.') % (name,))

class VanbandenController(Controller):

    #------------------------------------------------------
    # Controller vanbanden
    #------------------------------------------------------
    @route(['/web/dataset/call_kw/vanbanden.task/read'], type='json', auth="user")
    def load_vanbanden(self, model, method, args, kwargs, path=None):

        check_method_name(method)
        #When update user_id, system automatic call to automatically update follower_ids using super admin rights
        #at that time, our controller is expected to insert a key in context params
        #which allow us to by pass this case
        #if vals.get('user_id', None):
        #We also update user_id inside write() method of model, which does not cause to activate controller call
        #so that, we only create editable attribute in context that allow us to update later

        return call_kw(request.env[model], method, args, kwargs)
