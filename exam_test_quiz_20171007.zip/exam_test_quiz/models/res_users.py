# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class ResUsers(models.Model):
    """ Inherits partner and adds Tasks information in the partner form """
    _inherit = 'res.users'

    exam_id = fields.Many2many('etq.exam', 'etq_exam_user_rel', 'etq_user_id', 'etq_exam_id', string='Exam')

