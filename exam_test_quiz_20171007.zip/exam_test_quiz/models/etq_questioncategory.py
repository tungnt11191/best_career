# -*- coding: utf-8 -*-
from odoo import models, fields, api

from odoo.exceptions import UserError, ValidationError
#Import logger
import logging
#Get the logger
_logger = logging.getLogger(__name__)

#External import
import datetime

class etq_questioncategory(models.Model):
    _name = 'etq.questioncategory'
    name = fields.Char(required=True)
    description = fields.Html(string='Description')