# -*- coding: utf-8 -*-
from odoo import models, fields, api

from odoo.exceptions import UserError, ValidationError
#Import logger
import logging
#Get the logger
_logger = logging.getLogger(__name__)

#External import
import datetime

class etq_exam_random(models.Model):
    _name = 'etq.exam.random'
    exam_id = fields.Many2one('etq.exam', string="Exam ID")
    question_category_id = fields.Many2one('etq.questioncategory', string="Category")
    number_of_question = fields.Integer(string="Number of Questions")
    correct_score = fields.Integer(string="Correct score")
    incorrect_score = fields.Integer(string="Incorrect score")