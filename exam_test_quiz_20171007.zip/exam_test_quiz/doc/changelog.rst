v1.2.2
======
* Public Exams permissions

v1.2.1
======
* Exams mark as complete
* Add incomplete and complete filters
* Add image to questions

v1.2
====
* Use token system like survey
* Randomly select questions in the question pool

v1.1.2
======
* Fix miscalculated exam result percentage

v1.1.1
======
* Show percent score in background results

v1.1
====
* User in results, ability to see which option was choosen in result and multiple exams slug fix

v1.0.3
======
* Fix missing mail dependacy

v1.0.2
======
* Fix issue with missing csrf token

v1.0
====
* Initial release