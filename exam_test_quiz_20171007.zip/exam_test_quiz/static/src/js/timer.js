var Timer;
var TotalSeconds;
var Duration;
var FormId;
function CreateTimer(TimerID, Time , Form_id) {
Timer = document.getElementById(TimerID);
TotalSeconds = Time;
Duration = Time;
FormId = Form_id;
 UpdateTimer()
    window.setTimeout("Tick()", 1000);

}

function Tick() {
    if (TotalSeconds <= 0) {
    alert("Time's up!");
         document.getElementById(FormId).submit();
    return;
}

TotalSeconds -= 1;
UpdateTimer()
window.setTimeout("Tick()", 1000);
}

function UpdateTimer() {
var Seconds = TotalSeconds;

var Days = Math.floor(Seconds / 86400);
Seconds -= Days * 86400;

var Hours = Math.floor(Seconds / 3600);
Seconds -= Hours * (3600);

var Minutes = Math.floor(Seconds / 60);
Seconds -= Minutes * (60);


var TimeStr = ((Days > 0) ? Days + " days " : "") + LeadingZero(Hours) + ":" + LeadingZero(Minutes) + ":" + LeadingZero(Seconds)


Timer.innerHTML = TimeStr;
}


function LeadingZero(Time) {

    return (Time < 10) ? "0" + Time : + Time;

}


//timerId = setTimeout(submitform(FormId),1000);
function submitform(Form_id){
    console.log(Form_id);
    if(Form_id != undefined){
        clearTimeout(timerId);
        timerId = setTimeout(submitform(FormId), Duration * 1000);
        document.getElementById(Form_id).submit();
    }

}

var Tung_Timer = {
    Timer : 0,
    TotalSeconds : 0,
    Duration : 0,
    FormId : '',

    init : function(){

    }
}